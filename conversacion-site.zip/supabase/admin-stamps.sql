-- ConVerSacion: free admin passport stamps + shared admin account
-- Run once in the Supabase dashboard → SQL Editor.

-- 1) Stamps no longer need a session
ALTER TABLE public.passport_stamps ALTER COLUMN session_id DROP NOT NULL;
ALTER TABLE public.passport_stamps DROP CONSTRAINT IF EXISTS passport_stamps_user_id_session_id_key;
ALTER TABLE public.passport_stamps ADD COLUMN IF NOT EXISTS granted_by uuid REFERENCES auth.users(id) ON DELETE SET NULL;

-- 2) Only admins can add / remove stamps
GRANT INSERT, DELETE ON public.passport_stamps TO authenticated;
DROP POLICY IF EXISTS "admins add stamps" ON public.passport_stamps;
DROP POLICY IF EXISTS "admins remove stamps" ON public.passport_stamps;
CREATE POLICY "admins add stamps" ON public.passport_stamps FOR INSERT TO authenticated
  WITH CHECK (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "admins remove stamps" ON public.passport_stamps FOR DELETE TO authenticated
  USING (public.has_role(auth.uid(), 'admin'));

-- 3) Make the shared club account an admin (only once its email is confirmed)
CREATE OR REPLACE FUNCTION public.grant_club_admin()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF NEW.email_confirmed_at IS NOT NULL AND lower(NEW.email) = 'admincntrl@gmail.com' THEN
    INSERT INTO public.user_roles (user_id, role) VALUES (NEW.id, 'admin') ON CONFLICT DO NOTHING;
  END IF;
  RETURN NEW;
END $$;

DROP TRIGGER IF EXISTS on_auth_user_created_club_admin ON auth.users;
CREATE TRIGGER on_auth_user_created_club_admin AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.grant_club_admin();
DROP TRIGGER IF EXISTS on_auth_user_confirmed_club_admin ON auth.users;
CREATE TRIGGER on_auth_user_confirmed_club_admin AFTER UPDATE OF email_confirmed_at ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.grant_club_admin();

-- If the account already exists:
INSERT INTO public.user_roles (user_id, role)
SELECT id, 'admin' FROM auth.users
WHERE lower(email) = 'admincntrl@gmail.com' AND email_confirmed_at IS NOT NULL
ON CONFLICT DO NOTHING;
