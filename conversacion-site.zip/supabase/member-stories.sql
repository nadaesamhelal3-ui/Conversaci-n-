-- Member Stories: shared photo wall for club members.
-- Run once in the Supabase SQL Editor. Does not change any existing table.

create table if not exists public.member_stories (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete cascade not null,
  author_name text not null default 'Club member',
  caption text not null default '',
  image_data text not null,
  created_at timestamptz not null default now()
);

alter table public.member_stories enable row level security;

-- Everyone can read the stories wall.
create policy "Anyone can read member stories"
  on public.member_stories for select
  using (true);

-- Only logged-in members can post, and only as themselves.
create policy "Members can post their own stories"
  on public.member_stories for insert
  to authenticated
  with check (auth.uid() = user_id);

-- Members can delete only their own stories.
create policy "Members can delete their own stories"
  on public.member_stories for delete
  to authenticated
  using (auth.uid() = user_id);
