# ConVerSacion redesign

- [x] Audit uploaded source and preserve implemented behavior
- [x] Build mobile-first home experience
- [x] Preserve login, sign-up, sessions, voting, activities, and passport
- [x] Build the separate profile page
- [x] Validate phone, tablet, desktop, interactions, and build diagnostics