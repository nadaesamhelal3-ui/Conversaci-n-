import { useId } from "react";

import { cn } from "@/lib/utils";

/** Visa-style round "APPROVED" stamp with the club name in the middle. */
export function ClubStamp({ className, rotate = -8 }: { className?: string; rotate?: number | undefined }) {
  const id = useId().replace(/:/g, "");
  return (
    <svg
      viewBox="0 0 200 200"
      role="img"
      aria-label="ConVerSacion approved stamp"
      className={cn("text-stamp", className)}
      style={{ transform: `rotate(${rotate}deg)` }}
    >
      <defs>
        <path id={`top-${id}`} d="M 30 100 A 70 70 0 0 1 170 100" />
        <path id={`bot-${id}`} d="M 34 100 A 66 66 0 0 0 166 100" />
      </defs>
      <g fill="none" stroke="currentColor" opacity="0.92">
        <circle cx="100" cy="100" r="94" strokeWidth="5" />
        <circle cx="100" cy="100" r="86" strokeWidth="1.5" />
        <circle cx="100" cy="100" r="54" strokeWidth="1.5" strokeDasharray="3 3" />
      </g>
      <g fill="currentColor" opacity="0.92" fontFamily="'Nunito Sans', sans-serif" fontWeight="800">
        <text fontSize="17" letterSpacing="6">
          <textPath href={`#top-${id}`} startOffset="50%" textAnchor="middle">APPROVED</textPath>
        </text>
        <text fontSize="13" letterSpacing="4">
          <textPath href={`#bot-${id}`} startOffset="50%" textAnchor="middle" dominantBaseline="hanging">★ CLUB MEMBER ★</textPath>
        </text>
        <text x="100" y="106" textAnchor="middle" fontFamily="'Cormorant Garamond', serif" fontSize="25" fontWeight="700">
          ConVerSacion
        </text>
      </g>
    </svg>
  );
}
