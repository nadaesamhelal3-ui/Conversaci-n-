import { Link } from "@tanstack/react-router";
import {
  ArrowRight,
  BookOpen,
  CalendarDays,
  Globe,
  Heart,
  MessageCircle,
  Sparkles,
  Stamp,
  Star,
  UsersRound,
} from "lucide-react";
import { useState } from "react";

import clubImage from "@/assets/conversacion-club.jpg";
import cultureImage from "@/assets/highlight-culture.jpg";
import storiesImage from "@/assets/highlight-stories.jpg";
import gamesImage from "@/assets/highlight-games.jpg";
import { AuthDialog } from "@/components/auth-dialog";
import { BottomNav } from "@/components/bottom-nav";
import { Button } from "@/components/ui/button";
import { SiteHeader } from "@/components/site-header";
import { ClubStamp } from "@/components/club-stamp";
import { useAuthUser, useMyStampCount } from "@/lib/club-data";

const session = {
  title: "Topic of the Week",
  topic: "¿Viajar solo o con amigos?",
};

const highlights = [
  {
    title: "Cultural Corner",
    image: cultureImage,
    icon: Globe,
    to: "/magazine" as const,
  },
  {
    title: "Member Stories",
    image: storiesImage,
    icon: UsersRound,
    to: "/stories" as const,
  },
  {
    title: "Challenges & Games",
    image: gamesImage,
    icon: Star,
    to: "/challenges" as const,
  },
];

export function HomePage() {
  const [authMode, setAuthMode] = useState<"login" | "signup" | null>(null);
  const { user } = useAuthUser();
  const stampCount = useMyStampCount(user?.id);

  return (
    <div className="min-h-screen overflow-x-clip bg-background text-foreground">
      <SiteHeader onLogin={() => setAuthMode("login")} onSignup={() => setAuthMode("signup")} />

      <main className="mx-auto max-w-2xl px-4 pb-28 pt-6 sm:max-w-6xl sm:px-6 sm:pb-16 sm:pt-10">
        {/* Hero */}
        <section className="text-center">
          <div className="overflow-hidden rounded-3xl border border-border shadow-md">
            <img
              src={clubImage}
              alt="University students enjoying a Spanish conversation club gathering"
              width={1408}
              height={912}
              className="aspect-[4/3] w-full object-cover sm:aspect-[21/9]"
            />
          </div>
          <h1 className="mt-7 font-display text-5xl font-semibold leading-none text-primary sm:text-7xl">
            ¡Hablemos!
          </h1>
          <p className="mx-auto mt-4 max-w-md text-lg leading-8 text-muted-foreground">
            Un espacio para hablar, compartir y descubrir.
          </p>
        </section>

        {/* Next session card */}
        <section className="mt-8">
          <article className="rounded-3xl border border-border bg-card p-6 text-center shadow-sm sm:p-10">
            <span className="inline-block rounded-full bg-emerald-100 px-4 py-1.5 text-xs font-extrabold uppercase tracking-[0.12em] text-emerald-700">
              Next session
            </span>
            <h2 className="mt-5 font-display text-3xl font-semibold text-foreground sm:text-4xl">
              {session.title}
            </h2>
            <p className="mt-4 font-display text-2xl italic text-primary sm:text-3xl">
              {session.topic}
            </p>
            <p className="mt-4 flex items-center justify-center gap-2 text-sm text-muted-foreground">
              Weekly conversation session <CalendarDays className="size-4" />
            </p>
            <Button asChild className="mt-6 h-13 w-full rounded-2xl text-base sm:h-14 sm:text-lg">
              <Link to="/sessions">Join the session</Link>
            </Button>
          </article>
        </section>

        {/* Magazine + Vote tiles */}
        <section className="mt-5 grid grid-cols-2 gap-4">
          <Link
            to="/magazine"
            className="group rounded-3xl bg-secondary p-5 text-left shadow-sm transition-transform hover:-translate-y-0.5 sm:p-7"
          >
            <BookOpen className="size-7 text-primary" strokeWidth={1.6} />
            <h3 className="mt-4 font-display text-xl font-semibold leading-tight text-foreground sm:text-2xl">
              Explore the magazine
            </h3>
            <p className="mt-2 text-sm leading-6 text-muted-foreground">
              Read, play and discover Spanish culture.
            </p>
            <ArrowRight className="mt-4 size-5 text-primary transition-transform group-hover:translate-x-1" />
          </Link>
          <Link
            to="/vote"
            className="group rounded-3xl bg-secondary p-5 text-left shadow-sm transition-transform hover:-translate-y-0.5 sm:p-7"
          >
            <MessageCircle className="size-7 text-primary" strokeWidth={1.6} />
            <h3 className="mt-4 font-display text-xl font-semibold leading-tight text-foreground sm:text-2xl">
              Vote for the next topic
            </h3>
            <p className="mt-2 text-sm leading-6 text-muted-foreground">
              Choose what we talk about next.
            </p>
            <ArrowRight className="mt-4 size-5 text-primary transition-transform group-hover:translate-x-1" />
          </Link>
        </section>

        {/* Become a member */}
        <section className="mt-5">
          <div className="flex flex-col items-start gap-4 rounded-3xl bg-muted p-6 sm:flex-row sm:items-center sm:gap-6 sm:p-8">
            <UsersRound className="size-12 shrink-0 text-primary" strokeWidth={1.4} />
            <div className="min-w-0 flex-1">
              <h3 className="font-display text-2xl font-semibold text-foreground sm:text-3xl">
                Become a member!
              </h3>
              <p className="mt-1 text-sm leading-6 text-muted-foreground sm:text-base">
                Join the Spanish Conversation Club and be part of our community.
              </p>
            </div>
            <Button
              className="h-12 shrink-0 rounded-2xl px-6"
              onClick={() => setAuthMode(user ? null : "signup")}
            >
              Join now <ArrowRight />
            </Button>
          </div>
        </section>

        {/* Club highlights */}
        <section className="mt-10">
          <div className="flex items-end justify-between gap-3">
            <h2 className="font-display text-3xl font-semibold text-foreground sm:text-4xl">
              Club Highlights
            </h2>
            <Link
              to="/stories"
              className="flex shrink-0 items-center gap-1.5 text-sm font-semibold text-muted-foreground hover:text-primary"
            >
              View all <ArrowRight className="size-4" />
            </Link>
          </div>
          <div className="mt-5 grid grid-cols-3 gap-3 sm:gap-5">
            {highlights.map((item) => (
              <Link
                key={item.title}
                to={item.to}
                className="group relative overflow-hidden rounded-2xl shadow-sm sm:rounded-3xl"
              >
                <img
                  src={item.image}
                  alt={item.title}
                  width={800}
                  height={1008}
                  loading="lazy"
                  className="aspect-[4/5] w-full object-cover transition-transform duration-300 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/10 to-transparent" />
                <div className="absolute inset-x-0 bottom-0 p-3 sm:p-5">
                  <item.icon className="size-5 text-white sm:size-6" strokeWidth={1.8} />
                  <p className="mt-1.5 font-display text-base font-semibold leading-tight text-white sm:text-2xl">
                    {item.title}
                  </p>
                </div>
              </Link>
            ))}
          </div>
        </section>

        {/* Quote */}
        <section className="mt-8">
          <figure className="flex items-center justify-between gap-4 rounded-3xl bg-secondary p-6 sm:p-8">
            <Sparkles className="size-8 shrink-0 text-accent" strokeWidth={1.4} />
            <blockquote className="text-center font-display text-xl italic leading-8 text-primary sm:text-2xl">
              “El español no solo se aprende, se vive.”
            </blockquote>
            <Heart className="size-8 shrink-0 text-accent" strokeWidth={1.4} />
          </figure>
        </section>

        {/* Passport */}
        <section className="mt-10" id="passport">
          <div className="mb-5 text-center">
            <p className="text-xs font-bold uppercase tracking-[0.16em] text-accent">Your journey</p>
            <h2 className="mt-2 font-display text-3xl font-semibold text-primary sm:text-4xl">
              Digital Passport
            </h2>
            <p className="mx-auto mt-3 max-w-md leading-7 text-muted-foreground">
              Every conversation leaves a mark. Collect a new stamp when you attend a club session.
            </p>
          </div>
          <div className="relative rounded-3xl border-2 border-primary bg-card p-5 shadow-lg sm:p-8">
            <div className="pointer-events-none absolute inset-2 rounded-2xl border border-dashed border-primary/40" />
            <div className="relative flex items-center justify-between gap-4 border-b border-border pb-5">
              <div>
                <p className="text-xs font-bold uppercase tracking-[0.16em] text-accent">ConVerSacion</p>
                <h3 className="mt-1 font-display text-2xl text-primary">Club Passport</h3>
              </div>
              <Stamp className="size-10 shrink-0 text-primary" strokeWidth={1.4} />
            </div>
            <div className="relative mt-6 grid grid-cols-3 gap-3 sm:grid-cols-5">
              {Array.from({ length: Math.max(5, Math.ceil(stampCount / 5) * 5) }, (_, index) =>
                index < stampCount ? (
                  <ClubStamp key={index} className="aspect-square w-full" rotate={[-8, 6, -3, 10, -12][index % 5]} />
                ) : (
                  <div key={index} className="aspect-square rounded-full border-2 border-dashed border-border" />
                ),
              )}
            </div>
            <div className="relative mt-6 text-sm">
              <span className="font-semibold text-primary">
                {stampCount} {stampCount === 1 ? "stamp" : "stamps"}
              </span>
              <span className="text-muted-foreground"> · Stamps are added by club admins</span>
            </div>
          </div>
        </section>
      </main>

      <footer className="hidden border-t border-border bg-card py-10 sm:block">
        <div className="mx-auto grid max-w-6xl gap-7 px-4 sm:grid-cols-[1fr_auto] sm:px-6">
          <div>
            <p className="font-display text-2xl font-bold text-primary">ConVerSacion</p>
            <p className="mt-2 max-w-md text-sm text-muted-foreground">
              Spanish Conversation &amp; Culture Club for university students.
            </p>
          </div>
          <div className="grid grid-cols-2 gap-x-8 gap-y-3 text-sm font-semibold">
            <Link to="/sessions">Sessions</Link>
            <Link to="/vote">Vote</Link>
            <Link to="/challenges">Challenges</Link>
            <Link to="/stories">Stories</Link>
            <Link to="/magazine">Magazine</Link>
            <Link to="/profile">Profile</Link>
          </div>
        </div>
        <div className="mx-auto mt-8 max-w-6xl border-t border-border px-4 pt-5 text-xs text-muted-foreground sm:px-6">
          Speak Spanish. Connect. Create.
        </div>
      </footer>

      <BottomNav />
      <AuthDialog mode={authMode} onOpenChange={(open) => { if (!open) setAuthMode(null); }} />
    </div>
  );
}
