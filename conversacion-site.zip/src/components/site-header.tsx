import { Link } from "@tanstack/react-router";
import { BookOpen, CalendarDays, Menu, ShieldCheck, UserRound, UsersRound, Vote, X } from "lucide-react";
import { useState } from "react";

import { Button } from "@/components/ui/button";
import { useAuthUser, useIsAdmin } from "@/lib/club-data";

type SiteHeaderProps = {
  onLogin: () => void;
  onSignup: () => void;
};

const links = [
  { to: "/sessions", label: "Sessions", icon: CalendarDays },
  { to: "/challenges", label: "Challenges", icon: BookOpen },
  { to: "/vote", label: "Vote", icon: Vote },
  { to: "/stories", label: "Stories", icon: UsersRound },
] as const;

export function SiteHeader({ onLogin, onSignup }: SiteHeaderProps) {
  const [open, setOpen] = useState(false);
  const { user } = useAuthUser();
  const isAdmin = useIsAdmin(user?.id);

  return (
    <header className="sticky top-0 z-40 border-b border-border bg-background/95 backdrop-blur-md">
      <div className="mx-auto grid min-h-16 w-full max-w-6xl grid-cols-[minmax(0,1fr)_auto] items-center gap-3 px-4 sm:flex sm:min-h-20 sm:px-6">
        <Link to="/" className="flex min-w-0 items-center gap-3" aria-label="ConVerSacion home">
          <span className="grid size-10 shrink-0 place-items-center rounded-lg bg-primary font-display text-xl font-bold text-primary-foreground shadow-sm">
            C
          </span>
          <span className="min-w-0">
            <span className="block truncate font-display text-xl font-bold leading-none text-primary sm:text-2xl">ConVerSacion</span>
            <span className="mt-1 hidden text-[11px] font-semibold uppercase tracking-[0.14em] text-muted-foreground sm:block">
              Spanish Conversation & Culture Club
            </span>
          </span>
        </Link>

        <nav className="ml-auto hidden items-center gap-1 lg:flex" aria-label="Main navigation">
          {links.map((item) => (
            <Link key={item.to} to={item.to} className="rounded-md px-3 py-2 text-sm font-semibold text-muted-foreground transition-colors hover:bg-secondary hover:text-primary">
              {item.label}
            </Link>
          ))}
        </nav>

        <div className="ml-auto hidden items-center gap-2 sm:flex">
          {isAdmin && (
            <Button asChild variant="outline" className="h-11 border-primary px-4 text-primary">
              <Link to="/admin"><ShieldCheck /> Admin</Link>
            </Button>
          )}
          <Button variant="ghost" className="h-11 px-4 text-primary" onClick={onLogin}>Log in</Button>
          <Button className="h-11 px-5" onClick={onSignup}>Sign up</Button>
          <Button asChild variant="outline" size="icon" className="size-11" aria-label="Open profile">
            <Link to="/profile"><UserRound /></Link>
          </Button>
        </div>

        <Button
          variant="outline"
          size="icon"
          className="size-11 shrink-0 sm:hidden"
          onClick={() => setOpen((value) => !value)}
          aria-label={open ? "Close menu" : "Open menu"}
          aria-expanded={open}
        >
          {open ? <X /> : <Menu />}
        </Button>
      </div>

      {open && (
        <div className="border-t border-border bg-card px-4 py-4 sm:hidden">
          <nav className="grid gap-1" aria-label="Mobile navigation">
            {links.map((item) => (
              <Link key={item.to} to={item.to} onClick={() => setOpen(false)} className="flex min-h-12 items-center gap-3 rounded-md px-3 font-semibold text-foreground hover:bg-secondary">
                <item.icon className="size-5 text-accent" /> {item.label}
              </Link>
            ))}
            <Link to="/profile" onClick={() => setOpen(false)} className="flex min-h-12 items-center gap-3 rounded-md px-3 font-semibold text-foreground hover:bg-secondary">
              <UserRound className="size-5 text-accent" /> Profile
            </Link>
            {isAdmin && (
              <Link to="/admin" onClick={() => setOpen(false)} className="flex min-h-12 items-center gap-3 rounded-md px-3 font-semibold text-primary hover:bg-secondary">
                <ShieldCheck className="size-5 text-accent" /> Admin · Stamp passports
              </Link>
            )}
          </nav>
          <div className="mt-3 grid grid-cols-2 gap-2 border-t border-border pt-3">
            <Button variant="outline" className="h-12" onClick={() => { setOpen(false); onLogin(); }}>Log in</Button>
            <Button className="h-12" onClick={() => { setOpen(false); onSignup(); }}>Sign up</Button>
          </div>
        </div>
      )}
    </header>
  );
}