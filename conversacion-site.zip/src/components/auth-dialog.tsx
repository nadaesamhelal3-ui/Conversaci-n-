import type { FormEvent } from "react";
import { useState } from "react";

import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { supabase } from "@/lib/supabase";

type AuthDialogProps = {
  mode: "login" | "signup" | null;
  onOpenChange: (open: boolean) => void;
};

export function AuthDialog({ mode, onOpenChange }: AuthDialogProps) {
  const [message, setMessage] = useState("");
  const [busy, setBusy] = useState(false);
  const isSignup = mode === "signup";

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setBusy(true);
    setMessage(isSignup ? "Creating your account..." : "Logging in...");

    const form = new FormData(event.currentTarget);
    const email = String(form.get("email") ?? "").trim();
    const password = String(form.get("password") ?? "");
    const result = isSignup
      ? await supabase.auth.signUp({
          email,
          password,
          options: {
            data: {
              username: String(form.get("username") ?? "").trim(),
              full_name: String(form.get("fullName") ?? "").trim(),
            },
          },
        })
      : await supabase.auth.signInWithPassword({ email, password });

    setBusy(false);
    if (result.error) {
      setMessage(result.error.message);
      return;
    }
    setMessage(isSignup ? "Account created successfully!" : "Login successful!");
    window.setTimeout(() => onOpenChange(false), 900);
  }

  return (
    <Dialog open={mode !== null} onOpenChange={(open) => { setMessage(""); onOpenChange(open); }}>
      <DialogContent className="max-h-[calc(100dvh-24px)] w-[calc(100%-24px)] max-w-md overflow-y-auto rounded-lg border-border bg-card p-5 shadow-xl sm:p-7">
        <DialogHeader className="text-left">
          <span className="mb-2 grid size-11 place-items-center rounded-lg bg-primary font-display text-xl font-bold text-primary-foreground">C</span>
          <DialogTitle className="font-display text-3xl text-primary">{isSignup ? "Join the club" : "Welcome back"}</DialogTitle>
          <DialogDescription>{isSignup ? "Create your ConVerSacion account." : "Log in to join sessions and keep your progress."}</DialogDescription>
        </DialogHeader>
        <form className="grid gap-4" onSubmit={handleSubmit}>
          {isSignup && (
            <>
              <div className="grid gap-2">
                <Label htmlFor="fullName">Full name</Label>
                <Input id="fullName" name="fullName" autoComplete="name" required className="h-12 bg-background" />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="username">Username</Label>
                <Input id="username" name="username" autoComplete="username" required className="h-12 bg-background" />
              </div>
            </>
          )}
          <div className="grid gap-2">
            <Label htmlFor={`${mode}-email`}>Email</Label>
            <Input id={`${mode}-email`} name="email" type="email" autoComplete="email" required className="h-12 bg-background" />
          </div>
          <div className="grid gap-2">
            <Label htmlFor={`${mode}-password`}>Password</Label>
            <Input id={`${mode}-password`} name="password" type="password" minLength={6} autoComplete={isSignup ? "new-password" : "current-password"} required className="h-12 bg-background" />
          </div>
          <Button type="submit" className="mt-1 h-12 text-base" disabled={busy}>{isSignup ? "Create account" : "Log in"}</Button>
          {message && <p role="status" className="text-center text-sm text-muted-foreground">{message}</p>}
        </form>
      </DialogContent>
    </Dialog>
  );
}