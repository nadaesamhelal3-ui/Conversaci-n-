import { Link } from "@tanstack/react-router";
import { BookOpen, CalendarDays, House, Trophy, UserRound } from "lucide-react";

const items = [
  { to: "/", label: "Home", icon: House, exact: true },
  { to: "/sessions", label: "Sessions", icon: CalendarDays },
  { to: "/magazine", label: "Magazine", icon: BookOpen },
  { to: "/challenges", label: "Challenges", icon: Trophy },
  { to: "/profile", label: "Profile", icon: UserRound },
] as const;

/** Fixed bottom tab bar (mobile only), shared across pages. */
export function BottomNav() {
  return (
    <nav
      className="fixed inset-x-0 bottom-0 z-30 grid grid-cols-5 border-t border-border bg-card/95 px-2 pb-[max(8px,env(safe-area-inset-bottom))] pt-2 shadow-[0_-8px_24px_color-mix(in_oklab,var(--foreground)_8%,transparent)] backdrop-blur-md sm:hidden"
      aria-label="Quick navigation"
    >
      {items.map((item) => (
        <Link
          key={item.to}
          to={item.to}
          activeOptions={{ exact: "exact" in item && item.exact }}
          className="flex min-h-12 flex-col items-center justify-center gap-1 text-[10px] font-semibold text-muted-foreground"
          activeProps={{ className: "text-primary" }}
        >
          <item.icon className="size-5" />
          {item.label}
        </Link>
      ))}
    </nav>
  );
}
