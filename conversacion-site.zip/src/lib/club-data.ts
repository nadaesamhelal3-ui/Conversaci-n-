import type { User } from "@supabase/supabase-js";
import { useCallback, useEffect, useState } from "react";

import { supabase } from "@/lib/supabase";

export function useAuthUser() {
  const [user, setUser] = useState<User | null>(null);
  const [ready, setReady] = useState(false);
  useEffect(() => {
    supabase.auth.getUser().then(({ data }) => {
      setUser(data.user ?? null);
      setReady(true);
    });
    const { data } = supabase.auth.onAuthStateChange((_e, session) => setUser(session?.user ?? null));
    return () => data.subscription.unsubscribe();
  }, []);
  return { user, ready };
}

/** Admin status comes from the user_roles table (server-checked by RLS). */
export function useIsAdmin(userId: string | undefined) {
  const [isAdmin, setIsAdmin] = useState(false);
  useEffect(() => {
    if (!userId) return setIsAdmin(false);
    supabase
      .rpc("has_role", { _user_id: userId, _role: "admin" })
      .then(({ data }) => setIsAdmin(data === true));
  }, [userId]);
  return isAdmin;
}

export function useMyStampCount(userId: string | undefined) {
  const [count, setCount] = useState(0);
  const load = useCallback(async () => {
    if (!userId) return setCount(0);
    const { count: c } = await supabase
      .from("passport_stamps")
      .select("id", { count: "exact", head: true })
      .eq("user_id", userId);
    setCount(c ?? 0);
  }, [userId]);
  useEffect(() => {
    void load();
  }, [load]);
  return count;
}

export type MemberStory = {
  id: string;
  user_id: string;
  author_name: string;
  caption: string;
  image_data: string;
  created_at: string;
};

/** Shared wall of member photos from club sessions (member_stories table). */
export function useMemberStories() {
  const [stories, setStories] = useState<MemberStory[]>([]);
  const [loaded, setLoaded] = useState(false);

  const load = useCallback(async () => {
    const { data } = await supabase
      .from("member_stories")
      .select("id, user_id, author_name, caption, image_data, created_at")
      .order("created_at", { ascending: false })
      .limit(60);
    setStories((data as MemberStory[] | null) ?? []);
    setLoaded(true);
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  const addStory = useCallback(
    async (story: { user_id: string; author_name: string; caption: string; image_data: string }) => {
      const { error } = await supabase.from("member_stories").insert(story);
      if (error) return error.message;
      await load();
      return null;
    },
    [load],
  );

  const removeStory = useCallback(
    async (id: string) => {
      const { error } = await supabase.from("member_stories").delete().eq("id", id);
      if (error) return error.message;
      await load();
      return null;
    },
    [load],
  );

  return { stories, loaded, addStory, removeStory };
}
