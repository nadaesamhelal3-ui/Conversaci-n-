import { createClient } from "@supabase/supabase-js";

const supabaseUrl = "https://bqlhetqehstrhqfsumxd.supabase.co";
const supabasePublishableKey = "sb_publishable_lWEm5_jW3-tLtqL0QZBOgA_oaQ50TZA";

export const supabase = createClient(supabaseUrl, supabasePublishableKey);