import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowLeft, ArrowRight, CalendarDays, MapPin } from "lucide-react";
import { useState } from "react";

import { AuthDialog } from "@/components/auth-dialog";
import { BottomNav } from "@/components/bottom-nav";
import { Button } from "@/components/ui/button";
import { useAuthUser } from "@/lib/club-data";

export const Route = createFileRoute("/sessions")({
  head: () => ({
    meta: [
      { title: "Sessions — ConVerSacion" },
      { name: "description", content: "Weekly Spanish conversation sessions at the ConVerSacion club." },
      { property: "og:title", content: "Sessions — ConVerSacion" },
      { property: "og:description", content: "One topic, one room, and a lot of Spanish." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: SessionsPage,
});

const session = {
  number: "01",
  title: "Travel & Adventure",
  topic: "¿A dónde viajarías si pudieras ir a cualquier lugar?",
  stamp: "✈",
};

function SessionsPage() {
  const { user } = useAuthUser();
  const [authMode, setAuthMode] = useState<"login" | "signup" | null>(null);

  function bookSession() {
    if (!user) setAuthMode("login");
  }

  return (
    <main className="min-h-screen bg-background px-4 pb-28 pt-6 text-foreground sm:px-6 sm:py-10">
      <div className="mx-auto max-w-2xl">
        <Button asChild variant="ghost" className="-ml-3 text-primary">
          <Link to="/"><ArrowLeft /> Back to club</Link>
        </Button>

        <header className="mt-5">
          <p className="text-xs font-bold uppercase tracking-[0.16em] text-accent">Every week</p>
          <h1 className="mt-2 font-display text-4xl font-semibold text-primary sm:text-5xl">
            Upcoming Session
          </h1>
          <p className="mt-3 leading-7 text-muted-foreground">
            One topic, one room, and a lot of Spanish. Join the conversation.
          </p>
        </header>

        <article className="mt-7 rounded-3xl border border-border bg-card p-6 shadow-sm sm:p-8">
          <div className="flex items-start justify-between gap-3">
            <span className="inline-block rounded-full bg-emerald-100 px-4 py-1.5 text-xs font-extrabold uppercase tracking-[0.12em] text-emerald-700">
              Next session
            </span>
            <span className="grid size-10 shrink-0 place-items-center rounded-xl bg-secondary font-display text-lg text-primary">
              {session.stamp}
            </span>
          </div>
          <h2 className="mt-5 font-display text-3xl font-semibold text-primary">{session.title}</h2>
          <p className="mt-2 font-display text-xl italic leading-8 text-foreground">{session.topic}</p>
          <div className="mt-5 grid gap-2 border-y border-border py-4 text-sm text-muted-foreground">
            <span className="flex items-center gap-2">
              <CalendarDays className="size-4 text-accent" /> Weekly conversation
            </span>
            <span className="flex items-center gap-2">
              <MapPin className="size-4 text-accent" /> Campus club room
            </span>
          </div>
          <Button className="mt-5 h-13 w-full rounded-2xl text-base" onClick={bookSession}>
            Book session <ArrowRight />
          </Button>
        </article>
      </div>
      <BottomNav />
      <AuthDialog mode={authMode} onOpenChange={(open) => { if (!open) setAuthMode(null); }} />
    </main>
  );
}
