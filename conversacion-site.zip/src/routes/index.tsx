import { createFileRoute } from "@tanstack/react-router";
import { HomePage } from "@/components/home-page";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "ConVerSacion — Spanish Conversation & Culture Club" },
      { name: "description", content: "Join a warm university community for Spanish conversation, culture, weekly sessions, challenges, and more." },
      { property: "og:title", content: "ConVerSacion — Spanish Conversation & Culture Club" },
      { property: "og:description", content: "Speak Spanish, discover culture, and connect with your university community." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: HomePage,
});
