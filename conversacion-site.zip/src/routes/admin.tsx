import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowLeft, Minus, Search, ShieldCheck, Stamp } from "lucide-react";
import { useCallback, useEffect, useMemo, useState } from "react";
import { toast } from "sonner";

import { ClubStamp } from "@/components/club-stamp";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useAuthUser, useIsAdmin } from "@/lib/club-data";
import { supabase } from "@/lib/supabase";

export const Route = createFileRoute("/admin")({
  ssr: false,
  head: () => ({
    meta: [
      { title: "Admin — Passport Stamps · ConVerSacion" },
      { name: "description", content: "Club admins stamp members' digital passports." },
      { property: "og:title", content: "Admin — ConVerSacion" },
      { property: "og:description", content: "Stamp members' ConVerSacion passports." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: AdminPage,
});

type Member = { id: string; username: string; full_name: string | null; stamps: number };

function AdminPage() {
  const { user, ready } = useAuthUser();
  const isAdmin = useIsAdmin(user?.id);
  const [members, setMembers] = useState<Member[]>([]);
  const [query, setQuery] = useState("");
  const [busy, setBusy] = useState<string | null>(null);

  const load = useCallback(async () => {
    const [{ data: profiles }, { data: stamps }] = await Promise.all([
      supabase.from("profiles").select("id, username, full_name").order("full_name"),
      supabase.from("passport_stamps").select("user_id"),
    ]);
    const counts = new Map<string, number>();
    (stamps ?? []).forEach((s: { user_id: string }) => counts.set(s.user_id, (counts.get(s.user_id) ?? 0) + 1));
    setMembers((profiles ?? []).map((p) => ({ ...p, stamps: counts.get(p.id) ?? 0 })));
  }, []);

  useEffect(() => {
    if (isAdmin) void load();
  }, [isAdmin, load]);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return q ? members.filter((m) => `${m.full_name ?? ""} ${m.username}`.toLowerCase().includes(q)) : members;
  }, [members, query]);

  async function addStamp(m: Member) {
    setBusy(m.id);
    const { error } = await supabase.from("passport_stamps").insert({ user_id: m.id, granted_by: user?.id });
    setBusy(null);
    if (error) { toast.error("Couldn't add the stamp", { description: error.message }); return; }
    toast.success(`Stamped ${m.full_name || m.username}'s passport`);
    void load();
  }

  async function removeStamp(m: Member) {
    setBusy(m.id);
    const { data } = await supabase.from("passport_stamps").select("id").eq("user_id", m.id).order("created_at", { ascending: false }).limit(1);
    const last = data?.[0];
    const { error } = last ? await supabase.from("passport_stamps").delete().eq("id", last.id) : { error: null };
    setBusy(null);
    if (error) { toast.error("Couldn't remove the stamp", { description: error.message }); return; }
    void load();
  }

  return (
    <main className="min-h-screen bg-background px-4 py-6 text-foreground sm:px-6 sm:py-10">
      <div className="mx-auto max-w-3xl">
        <Button asChild variant="ghost" className="-ml-3 text-primary"><Link to="/"><ArrowLeft /> Back to club</Link></Button>

        <header className="mt-4 flex items-center gap-4 rounded-lg border border-border bg-card p-5 shadow-sm">
          <ClubStamp className="size-20 shrink-0" />
          <div className="min-w-0">
            <p className="flex items-center gap-1.5 text-xs font-bold uppercase tracking-[0.16em] text-accent"><ShieldCheck className="size-4" /> Admin</p>
            <h1 className="mt-1 font-display text-3xl leading-tight text-primary">Passport stamps</h1>
            <p className="mt-1 text-sm text-muted-foreground">Give a member a club stamp in their digital passport.</p>
          </div>
        </header>

        {!ready ? null : !user ? (
          <Notice text="Log in with the admin account to stamp passports." />
        ) : !isAdmin ? (
          <Notice text="This page is only for club admins." />
        ) : (
          <section className="mt-6">
            <div className="relative">
              <Search className="pointer-events-none absolute left-3 top-1/2 size-5 -translate-y-1/2 text-muted-foreground" />
              <Input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search members by name" className="h-12 bg-card pl-10 text-base" />
            </div>
            <ul className="mt-4 grid gap-3">
              {filtered.map((m) => (
                <li key={m.id} className="flex flex-wrap items-center gap-3 rounded-lg border border-border bg-card p-4">
                  <div className="min-w-0 flex-1">
                    <p className="truncate font-semibold text-foreground">{m.full_name || m.username}</p>
                    <p className="truncate text-sm text-muted-foreground">@{m.username} · {m.stamps} {m.stamps === 1 ? "stamp" : "stamps"}</p>
                  </div>
                  <div className="flex gap-2">
                    <Button variant="outline" size="icon" aria-label="Remove last stamp" disabled={busy === m.id || m.stamps === 0} onClick={() => removeStamp(m)}><Minus /></Button>
                    <Button disabled={busy === m.id} onClick={() => addStamp(m)}><Stamp /> Stamp</Button>
                  </div>
                </li>
              ))}
              {filtered.length === 0 && <li className="rounded-lg border border-dashed border-border p-6 text-center text-muted-foreground">No members found.</li>}
            </ul>
          </section>
        )}
      </div>
    </main>
  );
}

function Notice({ text }: { text: string }) {
  return <p className="mt-6 rounded-lg border border-dashed border-border bg-card p-6 text-center text-muted-foreground">{text}</p>;
}
