import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowLeft, Award, BookOpen, CalendarCheck, Stamp, UserRound } from "lucide-react";

import { Button } from "@/components/ui/button";
import { useAuthUser, useMyStampCount } from "@/lib/club-data";

export const Route = createFileRoute("/profile")({
  head: () => ({
    meta: [
      { title: "My Profile — ConVerSacion" },
      { name: "description", content: "Your ConVerSacion club profile, attendance, activities, and digital passport." },
      { property: "og:title", content: "My Profile — ConVerSacion" },
      { property: "og:description", content: "Your Spanish conversation club journey and progress." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: ProfilePage,
});

function ProfilePage() {
  const { user } = useAuthUser();
  const stampCount = useMyStampCount(user?.id);
  return (
    <main className="min-h-screen bg-background px-4 py-6 text-foreground sm:px-6 sm:py-10">
      <div className="mx-auto max-w-4xl">
        <Button asChild variant="ghost" className="-ml-3 text-primary"><Link to="/"><ArrowLeft /> Back to club</Link></Button>
        <header className="mt-5 grid grid-cols-[auto_minmax(0,1fr)] items-center gap-4 border-b border-border pb-7 sm:gap-6">
          <div className="grid size-16 shrink-0 place-items-center rounded-full border-2 border-primary bg-secondary sm:size-20"><UserRound className="size-8 text-primary" /></div>
          <div className="min-w-0"><p className="text-xs font-bold uppercase tracking-[0.16em] text-accent">ConVerSacion member</p><h1 className="mt-1 truncate font-display text-4xl text-primary sm:text-5xl">My Profile</h1><p className="mt-2 text-sm text-muted-foreground">Welcome to your ConVerSacion profile.</p></div>
        </header>
        <section className="mt-8 grid gap-4 sm:grid-cols-3">
          <ProfileStat icon={CalendarCheck} value="0" label="Sessions attended" />
          <ProfileStat icon={Stamp} value={String(stampCount)} label="Passport stamps" />
          <ProfileStat icon={Award} value="A1" label="Spanish level" />
        </section>
        <section className="mt-8 rounded-lg border border-border bg-card p-5 shadow-sm sm:p-7">
          <p className="text-xs font-bold uppercase tracking-[0.16em] text-accent">Club journey</p>
          <h2 className="mt-2 font-display text-3xl text-primary">Your activity</h2>
          <div className="mt-6 grid place-items-center rounded-md border border-dashed border-border bg-background px-5 py-12 text-center">
            <BookOpen className="size-10 text-primary" strokeWidth={1.4} />
            <p className="mt-4 font-display text-xl text-primary">Your next conversation starts here</p>
            <p className="mt-2 max-w-sm text-sm leading-6 text-muted-foreground">Book a session or join a challenge to begin filling your club profile.</p>
            <Button asChild className="mt-5 h-11"><Link to="/">Explore the club</Link></Button>
          </div>
        </section>
      </div>
    </main>
  );
}

function ProfileStat({ icon: Icon, value, label }: { icon: typeof Stamp; value: string; label: string }) {
  return <div className="rounded-lg border border-border bg-card p-5"><Icon className="size-5 text-accent" /><strong className="mt-4 block font-display text-3xl text-primary">{value}</strong><span className="text-sm text-muted-foreground">{label}</span></div>;
}