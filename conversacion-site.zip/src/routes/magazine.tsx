import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowLeft, BookOpen, Globe, Sparkles } from "lucide-react";

import { BottomNav } from "@/components/bottom-nav";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/magazine")({
  head: () => ({
    meta: [
      { title: "Club Magazine — ConVerSacion" },
      { name: "description", content: "Read, play and discover Spanish culture with the ConVerSacion club magazine." },
      { property: "og:title", content: "Club Magazine — ConVerSacion" },
      { property: "og:description", content: "Read, play and discover Spanish culture." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: MagazinePage,
});

function MagazinePage() {
  return (
    <main className="min-h-screen bg-background px-4 pb-28 pt-6 text-foreground sm:px-6 sm:py-10">
      <div className="mx-auto max-w-2xl">
        <Button asChild variant="ghost" className="-ml-3 text-primary">
          <Link to="/"><ArrowLeft /> Back to club</Link>
        </Button>

        <header className="mt-5 text-center">
          <span className="inline-grid size-14 place-items-center rounded-full bg-secondary">
            <BookOpen className="size-7 text-primary" strokeWidth={1.6} />
          </span>
          <p className="mt-4 text-xs font-bold uppercase tracking-[0.16em] text-accent">Cultural corner</p>
          <h1 className="mt-2 font-display text-4xl font-semibold text-primary sm:text-5xl">
            Club Magazine
          </h1>
          <p className="mx-auto mt-3 max-w-md leading-7 text-muted-foreground">
            Read, play and discover Spanish culture.
          </p>
        </header>

        <div className="mt-8 grid place-items-center rounded-3xl border border-dashed border-border bg-card px-6 py-16 text-center">
          <Globe className="size-10 text-primary" strokeWidth={1.4} />
          <p className="mt-4 font-display text-2xl text-primary">The magazine is coming soon</p>
          <p className="mt-2 max-w-sm text-sm leading-6 text-muted-foreground">
            Stories, culture notes, and games from the club will live here.
          </p>
          <Button asChild variant="outline" className="mt-5 h-11 rounded-2xl border-primary text-primary">
            <Link to="/vote">Vote for the next topic <Sparkles /></Link>
          </Button>
        </div>
      </div>
      <BottomNav />
    </main>
  );
}
