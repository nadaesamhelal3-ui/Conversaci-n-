import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowLeft, Check, MessageCircle } from "lucide-react";
import { useState } from "react";

import { BottomNav } from "@/components/bottom-nav";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/vote")({
  head: () => ({
    meta: [
      { title: "Vote for the Next Topic — ConVerSacion" },
      { name: "description", content: "Choose what the ConVerSacion club talks about next week." },
      { property: "og:title", content: "Vote for the Next Topic — ConVerSacion" },
      { property: "og:description", content: "The club decides together what we talk about next." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: VotePage,
});

const pollOptions = [
  ["Viajes y aventuras", 0],
  ["Música y artistas", 0],
  ["Películas y series", 0],
  ["Cultura española", 0],
] as const;

function VotePage() {
  const [selectedPoll, setSelectedPoll] = useState<string | null>(null);
  const [notice, setNotice] = useState("");

  function vote() {
    if (!selectedPoll) {
      setNotice("Please choose a topic first.");
      return;
    }
    setNotice(`You selected: ${selectedPoll}`);
  }

  return (
    <main className="min-h-screen bg-background px-4 pb-28 pt-6 text-foreground sm:px-6 sm:py-10">
      <div className="mx-auto max-w-2xl">
        <Button asChild variant="ghost" className="-ml-3 text-primary">
          <Link to="/"><ArrowLeft /> Back to club</Link>
        </Button>

        <header className="mt-5 text-center">
          <span className="inline-grid size-14 place-items-center rounded-full bg-secondary">
            <MessageCircle className="size-7 text-primary" strokeWidth={1.6} />
          </span>
          <p className="mt-4 text-xs font-bold uppercase tracking-[0.16em] text-accent">Your voice</p>
          <h1 className="mt-2 font-display text-4xl font-semibold text-primary sm:text-5xl">
            ¿De qué quieres hablar?
          </h1>
          <p className="mx-auto mt-3 max-w-md leading-7 text-muted-foreground">
            The club decides together what we talk about next week.
          </p>
        </header>

        <div className="mt-8 rounded-3xl border border-border bg-card p-5 shadow-sm sm:p-7">
          <div className="grid gap-3" role="radiogroup" aria-label="Weekly topics">
            {pollOptions.map(([label, votes]) => {
              const selected = selectedPoll === label;
              return (
                <Button
                  key={label}
                  type="button"
                  variant="outline"
                  role="radio"
                  aria-checked={selected}
                  onClick={() => setSelectedPoll(label)}
                  className={`grid h-auto min-h-14 w-full grid-cols-[minmax(0,1fr)_auto] justify-stretch whitespace-normal rounded-2xl px-4 py-3 text-left ${
                    selected ? "border-primary bg-secondary text-primary" : "bg-card"
                  }`}
                >
                  <span className="min-w-0 font-semibold">{label}</span>
                  <span className="ml-3 flex shrink-0 items-center gap-2 text-xs text-muted-foreground">
                    {votes} votes {selected && <Check className="size-4 text-primary" />}
                  </span>
                </Button>
              );
            })}
          </div>
          <Button className="mt-5 h-13 w-full rounded-2xl text-base" onClick={vote}>
            Cast your vote
          </Button>
          {notice && (
            <p role="status" className="mt-3 text-center text-sm font-medium text-accent">
              {notice}
            </p>
          )}
        </div>
      </div>
      <BottomNav />
    </main>
  );
}
