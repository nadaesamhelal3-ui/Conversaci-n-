import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowLeft, ArrowRight, CircleHelp, Trophy, UsersRound } from "lucide-react";

import { BottomNav } from "@/components/bottom-nav";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/challenges")({
  head: () => ({
    meta: [
      { title: "Challenges & Games — ConVerSacion" },
      { name: "description", content: "Practice Spanish through quick games, friendly competition, and conversation." },
      { property: "og:title", content: "Challenges & Games — ConVerSacion" },
      { property: "og:description", content: "Learn Spanish through games and friendly competition." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: ChallengesPage,
});

const activities = [
  { title: "Quiz", description: "Answer Spanish questions before the timer runs out.", meta: "Solo · Timed", icon: CircleHelp },
  { title: "One vs One", description: "Challenge another member and compete in Spanish.", meta: "2 Players · Points", icon: Trophy },
  { title: "Team Challenge", description: "Work together, practice, and compete as a team.", meta: "Teams · Multiplayer", icon: UsersRound },
];

function ChallengesPage() {
  return (
    <main className="min-h-screen bg-background px-4 pb-28 pt-6 text-foreground sm:px-6 sm:py-10">
      <div className="mx-auto max-w-2xl">
        <Button asChild variant="ghost" className="-ml-3 text-primary">
          <Link to="/"><ArrowLeft /> Back to club</Link>
        </Button>

        <header className="mt-5">
          <p className="text-xs font-bold uppercase tracking-[0.16em] text-accent">Practice Spanish</p>
          <h1 className="mt-2 font-display text-4xl font-semibold text-primary sm:text-5xl">
            Challenges &amp; Games
          </h1>
          <p className="mt-3 leading-7 text-muted-foreground">
            Learn through quick games, friendly competition, and conversation.
          </p>
        </header>

        <div className="mt-7 grid gap-4">
          {activities.map((activity, index) => (
            <article
              key={activity.title}
              className="relative overflow-hidden rounded-3xl border border-border bg-card p-5 shadow-sm sm:p-6"
            >
              <div className="absolute inset-y-0 left-0 w-1.5 bg-accent" aria-hidden="true" />
              <div className="flex items-start gap-4">
                <span className="grid size-12 shrink-0 place-items-center rounded-2xl bg-secondary">
                  <activity.icon className="size-6 text-primary" strokeWidth={1.6} />
                </span>
                <div className="min-w-0 flex-1">
                  <p className="text-xs font-bold uppercase tracking-[0.14em] text-accent">
                    Challenge 0{index + 1}
                  </p>
                  <h2 className="mt-1 font-display text-2xl text-primary">{activity.title}</h2>
                  <p className="mt-1.5 leading-6 text-muted-foreground">{activity.description}</p>
                  <p className="mt-4 border-t border-border pt-3 text-xs font-bold uppercase tracking-[0.1em] text-foreground">
                    {activity.meta}
                  </p>
                </div>
              </div>
              <Button variant="ghost" className="mt-2 text-primary">
                Explore challenge <ArrowRight />
              </Button>
            </article>
          ))}
        </div>
      </div>
      <BottomNav />
    </main>
  );
}
