import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowLeft, ImagePlus, Loader2, Trash2, UsersRound } from "lucide-react";
import { useRef, useState } from "react";

import { AuthDialog } from "@/components/auth-dialog";
import { BottomNav } from "@/components/bottom-nav";
import { Button } from "@/components/ui/button";
import { useAuthUser, useMemberStories } from "@/lib/club-data";

export const Route = createFileRoute("/stories")({
  head: () => ({
    meta: [
      { title: "Member Stories — ConVerSacion" },
      { name: "description", content: "Photos and moments shared by ConVerSacion club members from our sessions." },
      { property: "og:title", content: "Member Stories — ConVerSacion" },
      { property: "og:description", content: "Photos and moments shared by club members." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: StoriesPage,
});

/** Resize an image file to a small JPEG data URL so it fits in the database. */
function fileToDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    const url = URL.createObjectURL(file);
    img.onload = () => {
      const max = 900;
      const scale = Math.min(1, max / Math.max(img.width, img.height));
      const canvas = document.createElement("canvas");
      canvas.width = Math.round(img.width * scale);
      canvas.height = Math.round(img.height * scale);
      const ctx = canvas.getContext("2d");
      if (!ctx) {
        URL.revokeObjectURL(url);
        reject(new Error("Canvas not supported"));
        return;
      }
      ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
      URL.revokeObjectURL(url);
      resolve(canvas.toDataURL("image/jpeg", 0.8));
    };
    img.onerror = () => {
      URL.revokeObjectURL(url);
      reject(new Error("Could not read image"));
    };
    img.src = url;
  });
}

function StoriesPage() {
  const { user } = useAuthUser();
  const { stories, loaded, addStory, removeStory } = useMemberStories();
  const [authMode, setAuthMode] = useState<"login" | "signup" | null>(null);
  const [caption, setCaption] = useState("");
  const [imageData, setImageData] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState("");
  const fileInput = useRef<HTMLInputElement>(null);

  async function pickFile(file: File | undefined) {
    if (!file) return;
    try {
      setImageData(await fileToDataUrl(file));
      setNotice("");
    } catch {
      setNotice("Could not read that image. Try another one.");
    }
  }

  async function share() {
    if (!user) {
      setAuthMode("login");
      return;
    }
    if (!imageData) {
      setNotice("Choose a photo first.");
      return;
    }
    setBusy(true);
    const author =
      (user.user_metadata?.["full_name"] as string | undefined) ||
      (user.user_metadata?.["username"] as string | undefined) ||
      user.email ||
      "Club member";
    const error = await addStory({
      user_id: user.id,
      author_name: author,
      caption: caption.trim(),
      image_data: imageData,
    });
    setBusy(false);
    if (error) {
      setNotice("Could not share your story. Please try again.");
      return;
    }
    setCaption("");
    setImageData(null);
    if (fileInput.current) fileInput.current.value = "";
    setNotice("Your story is live! ¡Gracias por compartir!");
  }

  return (
    <main className="min-h-screen bg-background px-4 pb-28 pt-6 text-foreground sm:px-6 sm:py-10">
      <div className="mx-auto max-w-2xl">
        <Button asChild variant="ghost" className="-ml-3 text-primary">
          <Link to="/"><ArrowLeft /> Back to club</Link>
        </Button>

        <header className="mt-5 text-center">
          <span className="inline-grid size-14 place-items-center rounded-full bg-secondary">
            <UsersRound className="size-7 text-primary" strokeWidth={1.6} />
          </span>
          <p className="mt-4 text-xs font-bold uppercase tracking-[0.16em] text-accent">Our community</p>
          <h1 className="mt-2 font-display text-4xl font-semibold text-primary sm:text-5xl">
            Member Stories
          </h1>
          <p className="mx-auto mt-3 max-w-md leading-7 text-muted-foreground">
            Photos and moments from our sessions, shared by the members themselves.
          </p>
        </header>

        {/* Share box */}
        <section className="mt-8 rounded-3xl border border-border bg-card p-5 shadow-sm sm:p-7">
          <h2 className="font-display text-2xl text-primary">Share a moment</h2>
          <input
            ref={fileInput}
            type="file"
            accept="image/*"
            className="hidden"
            onChange={(event) => void pickFile(event.target.files?.[0])}
          />
          <button
            type="button"
            onClick={() => fileInput.current?.click()}
            className="mt-4 grid w-full place-items-center gap-2 overflow-hidden rounded-2xl border-2 border-dashed border-border bg-background px-4 py-8 text-sm font-semibold text-muted-foreground transition-colors hover:border-primary hover:text-primary"
          >
            {imageData ? (
              <img src={imageData} alt="Selected story" className="max-h-64 rounded-xl object-cover" />
            ) : (
              <>
                <ImagePlus className="size-8 text-accent" strokeWidth={1.5} />
                Tap to choose a photo from a session
              </>
            )}
          </button>
          <textarea
            value={caption}
            onChange={(event) => setCaption(event.target.value)}
            placeholder="Say something about this moment… (optional)"
            rows={2}
            maxLength={280}
            className="mt-3 w-full resize-none rounded-2xl border border-input bg-background px-4 py-3 text-sm outline-none placeholder:text-muted-foreground focus:border-primary"
          />
          <Button className="mt-3 h-12 w-full rounded-2xl text-base" onClick={() => void share()} disabled={busy}>
            {busy && <Loader2 className="animate-spin" />}
            {user ? "Share with the club" : "Log in to share"}
          </Button>
          {notice && (
            <p role="status" className="mt-3 text-center text-sm font-medium text-accent">
              {notice}
            </p>
          )}
        </section>

        {/* Stories wall */}
        <section className="mt-8 grid gap-4">
          {loaded && stories.length === 0 && (
            <div className="grid place-items-center rounded-3xl border border-dashed border-border bg-card px-6 py-14 text-center">
              <UsersRound className="size-10 text-primary" strokeWidth={1.4} />
              <p className="mt-4 font-display text-xl text-primary">No stories yet</p>
              <p className="mt-2 max-w-sm text-sm leading-6 text-muted-foreground">
                Be the first to share a photo from a club session.
              </p>
            </div>
          )}
          {stories.map((story) => (
            <article key={story.id} className="overflow-hidden rounded-3xl border border-border bg-card shadow-sm">
              <img src={story.image_data} alt={story.caption || "Member story"} loading="lazy" className="w-full object-cover" />
              <div className="flex items-start justify-between gap-3 p-4">
                <div className="min-w-0">
                  <p className="truncate text-sm font-bold text-primary">{story.author_name}</p>
                  {story.caption && <p className="mt-1 text-sm leading-6 text-muted-foreground">{story.caption}</p>}
                </div>
                {user?.id === story.user_id && (
                  <Button
                    variant="ghost"
                    size="icon"
                    className="size-9 shrink-0 text-muted-foreground hover:text-destructive"
                    aria-label="Delete story"
                    onClick={() => void removeStory(story.id)}
                  >
                    <Trash2 className="size-4" />
                  </Button>
                )}
              </div>
            </article>
          ))}
        </section>
      </div>
      <BottomNav />
      <AuthDialog mode={authMode} onOpenChange={(open) => { if (!open) setAuthMode(null); }} />
    </main>
  );
}
